// Import AWS Comprehend with additional services
import { Comprehend, DetectSentimentCommand, DetectEntitiesCommand, DetectKeyPhrasesCommand, DetectDominantLanguageCommand, DetectPiiEntitiesCommand } from '@aws-sdk/client-comprehend';
import axios from 'axios';

// Initialize Comprehend client with AWS SDK v3
const comprehend = new Comprehend({ region: 'ap-southeast-1' });

// Google Custom Search credentials
const GOOGLE_API_KEY = 'AIzaSyBUSaMS_QO38WqKvqGISRTIVQyu_wncuUE';
const CSE_ID = '739608e4458bb4e4b';

// KEEP TRUSTED DOMAINS - This is essential for quality control
const trustedDomains = {
    // International high credibility
    "who.int": "high",
    "cdc.gov": "high",
    "bbc.com": "high",
    "apnews.com": "high",
    "reuters.com": "high",
    "bloomberg.com": "high",
    
    // Malaysian high credibility (government & established media)
    "bernama.com": "high",
    "thestar.com.my": "high",
    "nst.com.my": "high",
    "gov.my": "high",
    "moh.gov.my": "high",
    "bnm.gov.my": "high",
    "treasury.gov.my": "high",
    "dosm.gov.my": "high",
    
    // International medium credibility
    "washingtonpost.com": "medium",
    "cnn.com": "medium",
    "economist.com": "medium",
    "theguardian.com": "medium",
    "nytimes.com": "medium",
    "straitstimes.com": "medium",
    
    // Malaysian medium credibility
    "malaymail.com": "medium",
    "freemalaysiatoday.com": "medium",
    "malaysiakini.com": "medium",
    "theedgemalaysia.com": "medium",
    "theedgemarkets.com": "medium",
    "sinchew.com.my": "medium",
    "orientaldaily.com.my": "medium",
    "chinapress.com.my": "medium",
    "kosmo.com.my": "medium",
    "hmetro.com.my": "medium",
    "utusan.com.my": "medium",
    "bharian.com.my": "medium",
    "astroawani.com": "medium",
    "themalaysianinsight.com": "medium",
    "malaysiannow.com": "medium",
    "codebluenews.com": "medium",
    "thevibes.com": "medium",
    "focusmalaysia.my": "medium",
    "says.com": "medium",
    "worldofbuzz.com": "medium",
    "rojakdaily.com": "medium",
    "paultan.org": "medium",
    "soyacincau.com": "medium",
    "technave.com": "medium",
    "lowyat.net": "medium",
    "malaysiabusiness.com": "medium",
    "themalaysianreserve.com": "medium"
};

// Blocked domains that should never appear in results
const blockedDomains = [
    'reddit.com', 'facebook.com', 'twitter.com', 'instagram.com', 
    'tiktok.com', 'youtube.com', 'quora.com', 'yahoo.com',
    'blogspot.com', 'wordpress.com', 'medium.com', 'pinterest.com'
];

// Lambda handler
export const handler = async (event) => {
    try {
        console.log('Received event:', JSON.stringify(event, null, 2));

        let body;
        if (event.body) {
            body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        } else {
            body = event;
        }

        if (!body || !body.text || !body.text.trim()) {
            return {
                statusCode: 400,
                headers: { 
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                body: JSON.stringify({ 
                    error: 'Missing or empty required field: text' 
                })
            };
        }

        const text = body.text.trim();
        console.log('Processing text:', text);

        if (text.length < 3) {
            return {
                statusCode: 400,
                headers: { 
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                body: JSON.stringify({ 
                    error: 'Text too short for analysis (minimum 3 characters)' 
                })
            };
        }

        if (text.length > 5000) {
            return {
                statusCode: 400,
                headers: { 
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                body: JSON.stringify({ 
                    error: 'Text too long. Maximum 5000 characters allowed.' 
                })
            };
        }

        // Enhanced AWS Comprehend ML analysis
        const comprehendParams = { Text: text, LanguageCode: 'en' };
        
        console.log('=== CALLING AWS COMPREHEND ML SERVICES ===');
        
        let sentimentData, entitiesData, keyPhrasesData, languageData, piiData;
        try {
            const [sentiment, entities, keyPhrases, language, pii] = await Promise.all([
                comprehend.send(new DetectSentimentCommand(comprehendParams)),
                comprehend.send(new DetectEntitiesCommand(comprehendParams)),
                comprehend.send(new DetectKeyPhrasesCommand(comprehendParams)),
                comprehend.send(new DetectDominantLanguageCommand({ Text: text })),
                comprehend.send(new DetectPiiEntitiesCommand(comprehendParams))
            ]);
            
            sentimentData = sentiment;
            entitiesData = entities;
            keyPhrasesData = keyPhrases;
            languageData = language;
            piiData = pii;
            
            console.log('=== COMPREHEND ML RESULTS ===');
            console.log('Sentiment:', sentiment.Sentiment);
            console.log('Entities:', entities.Entities?.length || 0);
            console.log('Key Phrases:', keyPhrases.KeyPhrases?.length || 0);
            console.log('PII Entities:', pii.Entities?.length || 0);
            
        } catch (comprehendError) {
            console.error('Comprehend ML error:', comprehendError);
            return {
                statusCode: 500,
                headers: { 
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                body: JSON.stringify({ 
                    error: 'ML analysis service unavailable',
                    details: comprehendError.message 
                })
            };
        }

        // ML-driven text type classification (no hardcoded rules)
        const textType = classifyTextTypeWithML(text, sentimentData, entitiesData, keyPhrasesData, piiData);
        
        // ML-driven category determination using entity patterns
        const category = determineCategoryWithMLPatterns(entitiesData, keyPhrasesData, sentimentData, text);
        
        console.log('ML Analysis - Type:', textType, 'Category:', category);

        let sources = [];
        let credibility = 'low';

        // If ML classifies as statement, search and verify with trusted sources
        if (textType === 'statement') {
            try {
                console.log('=== STARTING TRUSTED SOURCE SEARCH ===');
                
                // Generate search query using ML entities and key phrases
                const searchQuery = buildSearchQueryFromML(entitiesData, keyPhrasesData, text);
                console.log('ML search query:', searchQuery);
                
                const googleUrl = `https://www.googleapis.com/customsearch/v1?key=${GOOGLE_API_KEY}&cx=${CSE_ID}&q=${encodeURIComponent(searchQuery)}`;
                
                const googleResp = await axios.get(googleUrl, {
                    timeout: 15000,
                    headers: { 'User-Agent': 'ML-Fact-Checker/2.0' }
                });
                
                const items = googleResp.data.items || [];
                console.log('Search results found:', items.length);

                if (items.length === 0) {
                    credibility = 'low';
                    sources.push({
                        title: "No search results found",
                        url: "",
                        snippet: "No sources found for verification"
                    });
                } else {
                    // ML-based relevance filtering
                    const relevantResults = filterRelevanceWithML(items, text, entitiesData, keyPhrasesData);
                    console.log('ML relevant results:', relevantResults.length);

                    if (relevantResults.length === 0) {
                        credibility = 'low';
                        sources.push({
                            title: "No relevant sources found",
                            url: "",
                            snippet: "ML analysis found no relevant matches"
                        });
                    } else {
                        // KEEP TRUSTED SOURCE FILTERING - This is essential!
                        const trustedResults = filterTrustedSources(relevantResults);
                        console.log('Trusted results after filtering:', trustedResults.length);
                        
                        if (trustedResults.length === 0) {
                            credibility = 'low';
                            sources.push({
                                title: "No trusted sources found",
                                url: "",
                                snippet: "Found relevant results but not from trusted news sources"
                            });
                        } else {
                            sources = trustedResults.slice(0, 3).map(item => ({
                                title: item.title,
                                url: item.link,
                                snippet: item.snippet || '',
                                relevanceScore: item.relevanceScore || 1.0,
                                trustLevel: item.credibilityLevel
                            }));
                            credibility = computeCredibilityFromTrustedSources(trustedResults);
                        }
                    }
                }
                
                console.log('Final credibility from trusted sources:', credibility);
                
            } catch (googleError) {
                console.error('Search error:', googleError);
                credibility = 'low';
                sources.push({
                    title: "Search service unavailable",
                    url: "",
                    snippet: "Unable to search for verification"
                });
            }
        } else {
            sources.push({
                title: "ML Classification: Opinion/Subjective",
                url: "",
                snippet: "AWS Comprehend ML analysis determined this is not a factual statement"
            });
            credibility = 'n/a';
        }

        // Return results with ML analysis + trusted source verification
        const response = {
            statusCode: 200,
            headers: { 
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
            },
            body: JSON.stringify({
                type: textType,
                category: category,
                credibility: credibility,
                sources: sources,
                sentiment: sentimentData.Sentiment,
                confidence: sentimentData.SentimentScore,
                entities: entitiesData?.Entities || [],
                keyPhrases: keyPhrasesData?.KeyPhrases || [],
                language: languageData?.Languages?.[0] || null,
                piiEntities: piiData?.Entities || [],
                timestamp: new Date().toISOString(),
                searchMode: "ml-analysis-trusted-sources"
            })
        };

        return response;

    } catch (error) {
        console.error('Unexpected error:', error);
        
        return {
            statusCode: 500,
            headers: { 
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify({ 
                error: 'Internal Server Error',
                message: error.message,
                timestamp: new Date().toISOString()
            })
        };
    }
};

// IMPROVED ML-driven text classification with enhanced opinion detection
function classifyTextTypeWithML(text, sentimentData, entitiesData, keyPhrasesData, piiData) {
    console.log('=== ML TEXT TYPE CLASSIFICATION ===');
    console.log('Input text:', text);
    
    const entities = entitiesData?.Entities || [];
    const keyPhrases = keyPhrasesData?.KeyPhrases || [];
    const piiEntities = piiData?.Entities || [];
    
    // ML scoring based on Comprehend confidence levels
    let factualIndicators = 0;
    let opinionIndicators = 0;
    
    // ENHANCED OPINION DETECTION PATTERNS
    
    // 1. Question patterns - strong opinion indicators
    const questionPatterns = [
        /^(how|why|what|when|where|which|who)\s/i,
        /\?$/,
        /how on earth/i,
        /why would/i,
        /what makes/i,
        /how come/i,
        /isn't it/i,
        /don't you think/i
    ];
    
    const hasQuestionPattern = questionPatterns.some(pattern => pattern.test(text.trim()));
    if (hasQuestionPattern) {
        opinionIndicators += 1.0;
        console.log('🔍 Question pattern detected - strong opinion indicator');
    }
    
    // 2. Subjective language patterns
    const subjectivePatterns = [
        /so (good|bad|amazing|terrible|wonderful|awful)/i,
        /very (good|bad|nice|poor|great)/i,
        /(amazing|incredible|unbelievable|fantastic)/i,
        /i think/i,
        /i believe/i,
        /in my opinion/i,
        /seems like/i,
        /looks like/i,
        /feels like/i
    ];
    
    const hasSubjectivePattern = subjectivePatterns.some(pattern => pattern.test(text));
    if (hasSubjectivePattern) {
        opinionIndicators += 0.8;
        console.log('💭 Subjective language pattern detected');
    }
    
    // 3. Evaluative/judgmental language
    const evaluativeWords = ['good', 'bad', 'best', 'worst', 'better', 'worse', 'amazing', 'terrible', 'excellent', 'poor'];
    const textLower = text.toLowerCase();
    const evaluativeCount = evaluativeWords.filter(word => textLower.includes(word)).length;
    if (evaluativeCount > 0) {
        opinionIndicators += evaluativeCount * 0.4;
        console.log(`📊 Evaluative words found: ${evaluativeCount}`);
    }
    
    // 4. Personal experience indicators
    const personalPatterns = [
        /people are/i,
        /everyone is/i,
        /they are so/i,
        /r\/\w+/i  // Reddit references
    ];
    
    const hasPersonalPattern = personalPatterns.some(pattern => pattern.test(text));
    if (hasPersonalPattern) {
        opinionIndicators += 0.6;
        console.log('👥 Personal/community reference detected');
    }
    
    // FACTUAL INDICATORS (refined)
    
    // High-confidence entities suggest factual content, BUT only if not in question context
    const highConfidenceEntities = entities.filter(e => e.Score > 0.8);
    if (!hasQuestionPattern) {  // Don't count entities as factual if it's a question
        factualIndicators += highConfidenceEntities.length * 0.2;  // Reduced weight
    }
    console.log(`High confidence entities (>0.8): ${highConfidenceEntities.length}`);
    
    // Specific factual entity types - but weight down if in question
    const factualEntityTypes = ['PERSON', 'ORGANIZATION', 'DATE', 'QUANTITY', 'EVENT'];
    const factualEntities = entities.filter(e => factualEntityTypes.includes(e.Type) && e.Score > 0.7);
    
    if (hasQuestionPattern) {
        // Questions about factual entities are still opinions/inquiries
        factualIndicators += factualEntities.length * 0.1;
    } else {
        factualIndicators += factualEntities.length * 0.4;
    }
    console.log(`Factual entities (score >0.7): ${factualEntities.length}`);
    
    // Strong key phrases - but consider context
    const strongKeyPhrases = keyPhrases.filter(p => p.Score > 0.9);
    if (!hasQuestionPattern) {
        factualIndicators += strongKeyPhrases.length * 0.15;  // Reduced weight
    }
    console.log(`Strong key phrases (>0.9): ${strongKeyPhrases.length}`);
    
    // PII entities
    if (!hasQuestionPattern) {
        factualIndicators += piiEntities.length * 0.2;
    }
    console.log(`PII entities found: ${piiEntities.length}`);
    
    // SENTIMENT-BASED OPINION DETECTION (enhanced)
    const sentimentScores = sentimentData.SentimentScore;
    const maxSentiment = Math.max(sentimentScores.Positive, sentimentScores.Negative, sentimentScores.Mixed);
    
    // Strong emotional sentiment suggests opinion
    if (maxSentiment > 0.7 && sentimentData.Sentiment !== 'NEUTRAL') {
        opinionIndicators += 0.7;
        console.log(`Strong ${sentimentData.Sentiment} sentiment detected: ${maxSentiment.toFixed(2)}`);
    }
    
    // Mixed sentiment often indicates opinion/evaluation
    if (sentimentScores.Mixed > 0.4) {
        opinionIndicators += 0.5;
        console.log(`Mixed sentiment detected: ${sentimentScores.Mixed.toFixed(2)}`);
    }
    
    // ADDITIONAL HEURISTICS
    
    // Short text with few entities is likely opinion
    if (text.length < 50 && entities.length <= 2) {
        opinionIndicators += 0.4;
        console.log('Short text with few entities - likely opinion');
    }
    
    // Exclamatory language
    if (text.includes('!') || /\b(so|very|really|extremely)\s/i.test(text)) {
        opinionIndicators += 0.3;
        console.log('Exclamatory/intensifying language detected');
    }
    
    // Reddit-specific pattern (strong opinion indicator)
    if (/r\/\w+/.test(text)) {
        opinionIndicators += 0.8;
        console.log('Reddit community reference - strong opinion indicator');
    }
    
    console.log(`\n=== FINAL ML SCORES ===`);
    console.log(`ML Factual Score: ${factualIndicators.toFixed(2)}`);
    console.log(`ML Opinion Score: ${opinionIndicators.toFixed(2)}`);
    
    // Adjusted threshold - need stronger factual evidence to override opinion indicators
    const isFactual = factualIndicators > (opinionIndicators + 0.5);
    const result = isFactual ? 'statement' : 'opinion';
    
    console.log(`ML Classification: ${result.toUpperCase()} (confidence: ${Math.abs(factualIndicators - opinionIndicators).toFixed(2)})`);
    console.log('========================\n');
    
    return result;
}

// ML-based category determination using entity type patterns
function determineCategoryWithMLPatterns(entitiesData, keyPhrasesData, sentimentData, text) {
    console.log('=== ML CATEGORY ANALYSIS ===');
    
    const entities = entitiesData?.Entities || [];
    const keyPhrases = keyPhrasesData?.KeyPhrases || [];
    
    // Analyze ML-detected patterns
    const entityTypes = entities.map(e => e.Type);
    const highConfidenceEntities = entities.filter(e => e.Score > 0.8);
    const strongPhrases = keyPhrases.filter(p => p.Score > 0.8);
    
    console.log('Entity types found:', entityTypes);
    console.log('High confidence entities:', highConfidenceEntities.map(e => e.Text));
    console.log('Strong phrases:', strongPhrases.map(p => p.Text));
    
    // ML pattern detection for categories
    
    // Legal/Crime pattern: PERSON/QUANTITY + crime-related phrases
    if (entityTypes.includes('PERSON') || entityTypes.includes('QUANTITY')) {
        const crimePatterns = strongPhrases.some(p => {
            const phraseText = p.Text.toLowerCase();
            return phraseText.includes('crime') || phraseText.includes('criminal') ||
                   phraseText.includes('murder') || phraseText.includes('manslaughter') ||
                   phraseText.includes('assault') || phraseText.includes('battery') ||
                   phraseText.includes('arrest') || phraseText.includes('police') ||
                   phraseText.includes('cop') || phraseText.includes('robbery') ||
                   phraseText.includes('theft') || phraseText.includes('burglary') ||
                   phraseText.includes('homicide') || phraseText.includes('kidnap') ||
                   phraseText.includes('abduction') || phraseText.includes('rape') ||
                   phraseText.includes('sexual assault') || phraseText.includes('molest') ||
                   phraseText.includes('harassment') || phraseText.includes('threat') ||
                   phraseText.includes('violence') || phraseText.includes('fraud') ||
                   phraseText.includes('scam') || phraseText.includes('embezzlement') ||
                   phraseText.includes('forgery') || phraseText.includes('looting') ||
                   phraseText.includes('smuggling') || phraseText.includes('trafficking') ||
                   phraseText.includes('terror') || phraseText.includes('bomb') ||
                   phraseText.includes('arson') || phraseText.includes('vandalism') ||
                   phraseText.includes('trespass') || phraseText.includes('intimidation') ||
                   phraseText.includes('hate crime') || phraseText.includes('child abuse') ||
                   phraseText.includes('domestic violence') || phraseText.includes('gun') ||
                   phraseText.includes('weapon') || phraseText.includes('shooting') ||
                   phraseText.includes('blackmail') || phraseText.includes('defamation') ||
                   phraseText.includes('extortion') || phraseText.includes('corruption') ||
                   phraseText.includes('bribery') || phraseText.includes('stalking') ||
                   phraseText.includes('cybercrime') || phraseText.includes('identity theft') ||
                   phraseText.includes('piracy') || phraseText.includes('illegal') ||
                   phraseText.includes('drug trafficking') || phraseText.includes('prostitution') ||
                   phraseText.includes('trial') || phraseText.includes('court') ||
                   phraseText.includes('judge') || phraseText.includes('jury') ||
                   phraseText.includes('conviction') || phraseText.includes('sentence') ||
                   phraseText.includes('imprison') || phraseText.includes('parole');
        });

        if (crimePatterns) {
            console.log('ML detected Legal/Crime pattern');
            return 'Legal/Crime';
        }
    }

    // Sports pattern: EVENT/PERSON + sports phrases
    if (entityTypes.includes('EVENT') || entityTypes.includes('PERSON')) {
        const sportsPatterns = strongPhrases.some(p => {
            const phraseText = p.Text.toLowerCase();
            return phraseText.includes('sport') || phraseText.includes('team') ||
                   phraseText.includes('player') || phraseText.includes('coach') ||
                   phraseText.includes('referee') || phraseText.includes('match') ||
                   phraseText.includes('game') || phraseText.includes('competition') ||
                   phraseText.includes('tournament') || phraseText.includes('championship') ||
                   phraseText.includes('league') || phraseText.includes('final') ||
                   phraseText.includes('score') || phraseText.includes('victory') ||
                   phraseText.includes('defeat') || phraseText.includes('goal') ||
                   phraseText.includes('points') || phraseText.includes('medal') ||
                   phraseText.includes('trophy') || phraseText.includes('world cup') ||
                   phraseText.includes('olympics') || phraseText.includes('training') ||
                   phraseText.includes('stadium') || phraseText.includes('arena') ||
                   phraseText.includes('field') || phraseText.includes('court') ||
                   phraseText.includes('pitch') || phraseText.includes('track') ||
                   phraseText.includes('bat') || phraseText.includes('ball') ||
                   phraseText.includes('racket') || phraseText.includes('helmet') ||
                   phraseText.includes('fan') || phraseText.includes('crowd') ||
                   phraseText.includes('foul') || phraseText.includes('penalty') ||
                   phraseText.includes('offside') || phraseText.includes('kick') ||
                   phraseText.includes('pass') || phraseText.includes('shoot') ||
                   phraseText.includes('tackle') || phraseText.includes('serve') ||
                   phraseText.includes('sprint') || phraseText.includes('marathon') ||
                   phraseText.includes('boxing') || phraseText.includes('wrestling') ||
                   phraseText.includes('karate') || phraseText.includes('judo') ||
                   phraseText.includes('swimming') || phraseText.includes('cycling') ||
                   phraseText.includes('skiing') || phraseText.includes('rugby') ||
                   phraseText.includes('football') || phraseText.includes('soccer') ||
                   phraseText.includes('cricket') || phraseText.includes('baseball') ||
                   phraseText.includes('basketball') || phraseText.includes('volleyball') ||
                   phraseText.includes('hockey') || phraseText.includes('badminton') ||
                   phraseText.includes('tennis') || phraseText.includes('golf');
        });

        if (sportsPatterns) {
            console.log('ML detected Sports pattern');
            return 'Sports';
        }
    }

    // Politics pattern: PERSON/ORGANIZATION + political phrases
    if (entityTypes.includes('PERSON') || entityTypes.includes('ORGANIZATION')) {
        const politicsPatterns = strongPhrases.some(p => {
            const phraseText = p.Text.toLowerCase();
            return phraseText.includes('politics') || phraseText.includes('government') ||
                   phraseText.includes('minister') || phraseText.includes('president') ||
                   phraseText.includes('prime minister') || phraseText.includes('parliament') ||
                   phraseText.includes('senate') || phraseText.includes('congress') ||
                   phraseText.includes('election') || phraseText.includes('vote') ||
                   phraseText.includes('campaign') || phraseText.includes('candidate') ||
                   phraseText.includes('democracy') || phraseText.includes('republic') ||
                   phraseText.includes('monarchy') || phraseText.includes('dictator') ||
                   phraseText.includes('party') || phraseText.includes('legislation') ||
                   phraseText.includes('law') || phraseText.includes('bill') ||
                   phraseText.includes('policy') || phraseText.includes('cabinet') ||
                   phraseText.includes('referendum') || phraseText.includes('coalition') ||
                   phraseText.includes('opposition') || phraseText.includes('constitution') ||
                   phraseText.includes('mayor') || phraseText.includes('council') ||
                   phraseText.includes('polling') || phraseText.includes('ballot') ||
                   phraseText.includes('corruption') || phraseText.includes('scandal') ||
                   phraseText.includes('budget') || phraseText.includes('tax') ||
                   phraseText.includes('defense') || phraseText.includes('military') ||
                   phraseText.includes('treaty') || phraseText.includes('alliance') ||
                   phraseText.includes('civil rights') || phraseText.includes('human rights');
        });

        if (politicsPatterns) {
            console.log('ML detected Politics pattern');
            return 'Politics';
        }
    }

    // Health pattern: health-related phrases
    const healthPatterns = strongPhrases.some(p => {
        const phraseText = p.Text.toLowerCase();
        return phraseText.includes('health') || phraseText.includes('medical') ||
               phraseText.includes('medicine') || phraseText.includes('doctor') ||
               phraseText.includes('nurse') || phraseText.includes('hospital') ||
               phraseText.includes('clinic') || phraseText.includes('treatment') ||
               phraseText.includes('therapy') || phraseText.includes('diagnosis') ||
               phraseText.includes('disease') || phraseText.includes('infection') ||
               phraseText.includes('virus') || phraseText.includes('bacteria') ||
               phraseText.includes('epidemic') || phraseText.includes('pandemic') ||
               phraseText.includes('covid') || phraseText.includes('influenza') ||
               phraseText.includes('flu') || phraseText.includes('vaccine') ||
               phraseText.includes('immunization') || phraseText.includes('pharmacy') ||
               phraseText.includes('drug') || phraseText.includes('medication') ||
               phraseText.includes('surgery') || phraseText.includes('operation') ||
               phraseText.includes('symptom') || phraseText.includes('fever') ||
               phraseText.includes('cough') || phraseText.includes('pain') ||
               phraseText.includes('mental health') || phraseText.includes('depression') ||
               phraseText.includes('anxiety') || phraseText.includes('stress') ||
               phraseText.includes('nutrition') || phraseText.includes('diet') ||
               phraseText.includes('exercise') || phraseText.includes('wellness') ||
               phraseText.includes('public health') || phraseText.includes('emergency') ||
               phraseText.includes('injury') || phraseText.includes('trauma') ||
               phraseText.includes('hygiene') || phraseText.includes('sanitation') ||
               phraseText.includes('diabetes') || phraseText.includes('cancer') ||
               phraseText.includes('stroke') || phraseText.includes('allergy') ||
               phraseText.includes('asthma') || phraseText.includes('side effect') ||
               phraseText.includes('hospitalization') || phraseText.includes('icu') ||
               phraseText.includes('ventilator') || phraseText.includes('quarantine') ||
               phraseText.includes('addiction') || phraseText.includes('smoking') ||
               phraseText.includes('alcoholism') || phraseText.includes('malnutrition');
    });

    if (healthPatterns) {
        console.log('ML detected Health pattern');
        return 'Health';
    }

    console.log('ML defaulting to General category');
    return 'General';
}

// Build search query using highest-scoring ML entities and phrases
function buildSearchQueryFromML(entitiesData, keyPhrasesData, text) {
    const entities = entitiesData?.Entities || [];
    const keyPhrases = keyPhrasesData?.KeyPhrases || [];
    
    // Get ML's highest confidence entities
    const topEntities = entities
        .filter(e => e.Score > 0.7)
        .sort((a, b) => b.Score - a.Score)
        .slice(0, 3)
        .map(e => e.Text);
    
    // Get ML's highest confidence key phrases
    const topPhrases = keyPhrases
        .filter(p => p.Score > 0.8)
        .sort((a, b) => b.Score - a.Score)
        .slice(0, 2)
        .map(p => p.Text);
    
    const searchTerms = [...topEntities, ...topPhrases];
    
    console.log('ML search terms:', searchTerms);
    
    return searchTerms.length > 0 ? searchTerms.join(' ') : text.split(' ').slice(0, 4).join(' ');
}

// ML-based relevance filtering using entity/phrase matching
function filterRelevanceWithML(items, text, entitiesData, keyPhrasesData) {
    console.log('=== ML RELEVANCE FILTERING ===');
    
    const entities = entitiesData?.Entities || [];
    const keyPhrases = keyPhrasesData?.KeyPhrases || [];
    
    const relevantResults = [];
    
    items.forEach((item, index) => {
        const title = (item.title || '').toLowerCase();
        const snippet = (item.snippet || '').toLowerCase();
        const content = title + ' ' + snippet;
        
        let relevanceScore = 0;
        
        // Score based on ML entity matches
        entities.forEach(entity => {
            const entityText = entity.Text.toLowerCase();
            if (content.includes(entityText)) {
                relevanceScore += entity.Score * 0.4;
            }
        });
        
        // Score based on ML key phrase matches
        keyPhrases.forEach(phrase => {
            const phraseText = phrase.Text.toLowerCase();
            if (content.includes(phraseText)) {
                relevanceScore += phrase.Score * 0.3;
            }
        });
        
        console.log(`Item ${index + 1} ML relevance: ${relevanceScore.toFixed(2)}`);
        
        // Only accept results with significant ML relevance
        if (relevanceScore > 0.5) {
            relevantResults.push({
                ...item,
                relevanceScore: relevanceScore
            });
        }
    });
    
    return relevantResults.sort((a, b) => b.relevanceScore - a.relevanceScore);
}

// KEEP TRUSTED SOURCE FILTERING - Essential for quality!
function filterTrustedSources(items) {
    console.log('=== FILTERING FOR TRUSTED SOURCES ===');
    
    const trustedResults = [];
    
    items.forEach(item => {
        try {
            if (item.link) {
                const url = new URL(item.link);
                const domain = url.hostname.replace('www.', '');
                
                // Check if blocked
                const isBlocked = blockedDomains.some(blocked => 
                    domain.includes(blocked) || blocked.includes(domain)
                );
                
                if (isBlocked) {
                    console.log(`❌ BLOCKED: ${domain}`);
                    return;
                }
                
                // Check if trusted
                const credibilityLevel = trustedDomains[domain];
                if (credibilityLevel) {
                    console.log(`✅ TRUSTED: ${domain} (${credibilityLevel})`);
                    trustedResults.push({
                        ...item,
                        domain: domain,
                        credibilityLevel: credibilityLevel
                    });
                } else {
                    console.log(`⚠️ NOT TRUSTED: ${domain}`);
                }
            }
        } catch(e) {
            console.error('Error parsing URL:', item.link);
        }
    });
    
    return trustedResults;
}

// Credibility based on trusted source levels
function computeCredibilityFromTrustedSources(trustedItems) {
    if (!trustedItems || trustedItems.length === 0) return 'low';
    
    let hasHigh = false;
    let hasMedium = false;
    
    trustedItems.forEach(item => {
        if (item.credibilityLevel === 'high') hasHigh = true;
        if (item.credibilityLevel === 'medium') hasMedium = true;
    });
    
    if (hasHigh) return 'high';
    if (hasMedium) return 'medium';
    return 'low';
}